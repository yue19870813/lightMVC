# lightMVC
light mvc
---
简易轻量级MVC框架，适用于中小型项目使用。后续会拓展lightMVC_ex内容来适应大型项目的开发。

#### 架构图
![架构图](./mvc.png)
