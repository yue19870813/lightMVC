/**
 * 命令基类
 */

export default class BaseCommand {

}
