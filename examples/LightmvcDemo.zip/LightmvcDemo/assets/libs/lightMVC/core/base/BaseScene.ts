import { BaseView } from "./BaseView";

const {ccclass, property} = cc._decorator;

@ccclass
export default class BaseScene extends BaseView {
    
}
