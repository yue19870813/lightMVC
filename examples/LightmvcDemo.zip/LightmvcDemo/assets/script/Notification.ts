
export default class Notification {

    static readonly UPDATE_EXP_FINISH = "UPDATE_EXP_FINISH";
    
}
