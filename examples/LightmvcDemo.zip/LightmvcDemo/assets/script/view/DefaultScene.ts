import BaseScene from "../../libs/lightMVC/core/base/BaseScene";

const {ccclass, property} = cc._decorator;

@ccclass
export default class DefaultScene extends BaseScene {

   
}
