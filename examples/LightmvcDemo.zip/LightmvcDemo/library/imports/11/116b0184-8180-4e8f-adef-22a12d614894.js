"use strict";
cc._RF.push(module, '116b0GEgYBOj63vIqEtYUiU', 'MacroCommand');
// libs/lightMVC/core/command/MacroCommand.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseCommand_1 = require("../base/BaseCommand");
/**
 * 组合类型命令基类
 */
var MacroCommand = /** @class */ (function (_super) {
    __extends(MacroCommand, _super);
    function MacroCommand() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /** 组合命令列表 */
        _this._commandList = [];
        return _this;
    }
    /**
     * 向组合宏中添加子命令
     * @param {{new (): SimpleCommand}} command 子命令
     * @param {Object} body 命令参数
     */
    MacroCommand.prototype.addSubCommand = function (command, body) {
        this._commandList.push({ cmd: command, body: body });
    };
    return MacroCommand;
}(BaseCommand_1.default));
exports.default = MacroCommand;

cc._RF.pop();