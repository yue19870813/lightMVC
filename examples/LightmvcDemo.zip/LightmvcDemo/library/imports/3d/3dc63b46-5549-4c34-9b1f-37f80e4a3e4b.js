"use strict";
cc._RF.push(module, '3dc63tGVUlMNJsfN/gOSj5L', 'Facade');
// libs/lightMVC/core/Facade.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ViewManager_1 = require("./manager/ViewManager");
var Constants_1 = require("./Constants");
var CommandManager_1 = require("./manager/CommandManager");
var ModelManager_1 = require("./manager/ModelManager");
var FrameworkCfg_1 = require("./FrameworkCfg");
var Facade = /** @class */ (function () {
    function Facade() {
    }
    Facade.getInstance = function () {
        return this._instance;
    };
    /**
     * 初始化框架配置
     * @param {boolean} debug 是否是调试状态
     * @param {cc.Size} designResolution 设计分辨率
     * @param {boolean} fitHeight 是否高适配
     * @param {boolean} fitWidth 是否宽适配
     */
    Facade.prototype.init = function (debug, designResolution, fitHeight, fitWidth) {
        if (Facade._isInit) {
            console.warn("框架已经初始化，不需要重复初始化。");
            return;
        }
        Facade._isInit = true;
        FrameworkCfg_1.default.DEBUG = debug;
        FrameworkCfg_1.default.DESIGN_RESOLUTION = designResolution;
        FrameworkCfg_1.default.FIT_HEIGHT = fitHeight;
        FrameworkCfg_1.default.FIT_WIDTH = fitWidth;
    };
    /**
     * 运行场景
     * @param {{new(): BaseMediator}} mediator 场景mediator类型，类类型。
     * @param {{new(): BaseScene}} view 场景mediator类型，类类型。
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     * @param {()=>void} cb 加载完成回调.
     */
    Facade.prototype.runScene = function (mediator, view, data, cb) {
        if (Facade._isInit) {
            ViewManager_1.ViewManager.getInstance().__runScene__(mediator, view, data, cb);
        }
        else {
            console.warn("框架没有初始化，请先调用init接口进行初始化。");
        }
    };
    /**
     * 返回上一场景
     * @returns {boolean}是否存在上一个场景
     */
    Facade.prototype.backScene = function () {
        return ViewManager_1.ViewManager.getInstance().__backScene__();
    };
    /**
     * 打开view界面，弹出界面
     * @param {{new(): BaseMediator}} mediator 界面mediator类型，类类型。
     * @param {{new(): BaseView}} view view 场景mediator类型，类类型。
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     * @param {()=>void} cb 加载完成回调.
     */
    Facade.prototype.popView = function (mediator, view, data, cb) {
        ViewManager_1.ViewManager.getInstance().__showView__(mediator, view, data, Constants_1.OPEN_VIEW_OPTION.OVERLAY, 0, cb);
    };
    /**
     * 创建view层，此接口用于初始不会被关闭和再次打开的常驻界面，所以它也不会受到pooView影响和管理。
     * @param {{new(): BaseMediator}} mediator 界面mediator类型，类类型。
     * @param {{new(): BaseView}} view view 场景mediator类型，类类型。
     * @param {number} zOrder ui层级
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     * @param {()=>void} cb 加载完成回调.
     */
    Facade.prototype.addLayer = function (mediator, view, zOrder, data, cb) {
        ViewManager_1.ViewManager.getInstance().__showView__(mediator, view, data, Constants_1.OPEN_VIEW_OPTION.LAYER, zOrder, cb);
    };
    /**
     * 撤销命令
     * @param {{new (): BaseCommand}} command 命令对象
     * @param {Object} body 命令参数
     */
    Facade.prototype.__undoCommand__ = function (command, body) {
        CommandManager_1.default.getInstance().__undoCommand__(command, body);
    };
    /**
     * 注册数据model
     * @param {{new (): BaseModel}} model
     */
    Facade.prototype.registerModel = function (model) {
        ModelManager_1.default.getInstance().registerModel(model);
    };
    /**
     * 获取model对象
     * @param {{new (): BaseModel}} model
     */
    Facade.prototype.getModel = function (model) {
        return ModelManager_1.default.getInstance().getModel(model);
    };
    /** 实例对象 */
    Facade._instance = new Facade();
    /** 框架是否被初始化 */
    Facade._isInit = false;
    return Facade;
}());
exports.Facade = Facade;
/** 导入到全局属性mvc中的对外接口和属性等api */
(window).mvc = {
    appFacade: Facade.getInstance(),
};

cc._RF.pop();