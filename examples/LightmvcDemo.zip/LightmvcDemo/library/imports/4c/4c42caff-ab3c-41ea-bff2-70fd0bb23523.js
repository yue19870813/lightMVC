"use strict";
cc._RF.push(module, '4c42cr/qzxB6r/ycP0LsjUj', 'UIUtils');
// libs/lightMVC/util/UIUtils.ts

Object.defineProperty(exports, "__esModule", { value: true });
var UIUtils = /** @class */ (function () {
    function UIUtils() {
    }
    /***
     * 生成子节点的唯一标识快捷访问
     * @param node
     * @param map
     */
    UIUtils.createSubNodeMap = function (node, map) {
        var children = node.children;
        if (!children) {
            return;
        }
        for (var t = 0, len = children.length; t < len; ++t) {
            var subChild = children[t];
            map.set(subChild.name, subChild);
            UIUtils.createSubNodeMap(subChild, map);
        }
    };
    /***
     * 返回当前节点所有节点,一唯一标识存在
     * @param node 父节点
     * @return {Object} 所有子节点的映射map
     */
    UIUtils.seekAllSubView = function (node) {
        var map = new Map();
        UIUtils.createSubNodeMap(node, map);
        return new UIContainer(map);
    };
    return UIUtils;
}());
exports.default = UIUtils;
var UIContainer = /** @class */ (function () {
    function UIContainer(nodesMap) {
        this._uiNodesMap = nodesMap;
    }
    /**
     * 根据节点名字获取节点
     * @param {string}name 节点名字
     * @return {cc.Node}
     */
    UIContainer.prototype.getNode = function (name) {
        return this._uiNodesMap.get(name);
    };
    /**
     * 根据节点名字和组件类型获取组件对象
     * @param {string}name 节点名字
     * @param {{prototype: cc.Component}}com 组建类型
     * @return {cc.Component}
     */
    UIContainer.prototype.getComponent = function (name, com) {
        var node = this._uiNodesMap.get(name);
        if (node) {
            return node.getComponent(com);
        }
        return null;
    };
    return UIContainer;
}());
exports.UIContainer = UIContainer;

cc._RF.pop();