"use strict";
cc._RF.push(module, '5528eRJKJJDCZ3uptYJk9x+', 'ViewEvent');
// libs/lightMVC/core/base/ViewEvent.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ViewEvent = /** @class */ (function () {
    function ViewEvent() {
        // 初始化事件列表
        this._eventList = [];
    }
    /**
     * 注册事件
     * @param {string} name 事件名称
     * @param {(any)=>void} cb 事件回调
     * @param {BaseMediator} target 绑定事件的对象
     */
    ViewEvent.prototype.on = function (name, cb, target) {
        var event = new __ViewEvent__(name, cb, target);
        for (var _i = 0, _a = this._eventList; _i < _a.length; _i++) {
            var e = _a[_i];
            if (e.equals(event)) {
                console.log("事件[" + name + "]已存在！");
                return;
            }
        }
        this._eventList.push(event);
    };
    /**
     * 派发事件
     * @param {string} name 事件名称
     * @param {Object} body 事件参数，动态参数列表
     */
    ViewEvent.prototype.emit = function (name, body) {
        for (var _i = 0, _a = this._eventList; _i < _a.length; _i++) {
            var e = _a[_i];
            if (e.name === name) {
                e.cb && e.cb.call(e.target, body);
                break;
            }
        }
    };
    /**
     * 移除指定事件
     * @param {string} name 事件名称
     * @return {boolean} 是否移除
     */
    ViewEvent.prototype.remove = function (name) {
        // 移除指定事件
        for (var i = 0; i < this._eventList.length; i++) {
            if (name === this._eventList[i].name) {
                this._eventList.splice(i, 1);
                return true;
            }
        }
        return false;
    };
    /**
     * 销毁接口
     */
    ViewEvent.prototype.destroy = function () {
    };
    return ViewEvent;
}());
exports.default = ViewEvent;
/**
 * 事件对象结构，用于内部使用。
 * @private
 */
var __ViewEvent__ = /** @class */ (function () {
    /***
     * @param {string} name 事件名称
     * @param {(...args)=>void} cb 事件回调
     * @param {BaseMediator} target 绑定事件的对象
     */
    function __ViewEvent__(name, cb, target) {
        this.name = name;
        this.cb = cb;
        this.target = target;
    }
    /**
     * 判断两个对象是否相等
     * @param {__ViewEvent__} event 目标事件对象
     * @return {boolean} 是否相等
     */
    __ViewEvent__.prototype.equals = function (event) {
        return this.name === event.name;
    };
    return __ViewEvent__;
}());

cc._RF.pop();