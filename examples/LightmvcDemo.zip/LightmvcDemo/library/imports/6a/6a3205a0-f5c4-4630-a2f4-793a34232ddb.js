"use strict";
cc._RF.push(module, '6a320Wg9cRGMKL0eTo0Iy3b', 'FirstView');
// script/view/first/FirstView.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseView_1 = require("../../../libs/lightMVC/core/base/BaseView");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var FirstView = /** @class */ (function (_super) {
    __extends(FirstView, _super);
    function FirstView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FirstView_1 = FirstView;
    FirstView.prototype.start = function () {
        var _this = this;
        var aBtnNode = this.ui.getNode("a_btn");
        aBtnNode.on(cc.Node.EventType.TOUCH_END, function () {
            _this.sendEvent(FirstView_1.OPEN_A, "AAA");
        }, this);
        var bBtnNode = this.ui.getNode("b_btn");
        bBtnNode.on(cc.Node.EventType.TOUCH_END, function () {
            _this.sendEvent(FirstView_1.OPEN_B, "BBB");
        }, this);
        var closeBtnNode = this.ui.getNode("close_btn");
        closeBtnNode.on(cc.Node.EventType.TOUCH_END, this.closeAllView, this);
    };
    FirstView.prototype.setData = function (str) {
        var desLabel = this.ui.getComponent("des_label", cc.Label);
        desLabel.string = "这是第一个UI，根据prefab创建，打开场景时传入的参数是：" + str;
    };
    FirstView.prototype.closeAllView = function () {
        this.closeAllPopView();
    };
    FirstView.path = function () {
        return "prefabs/first_view";
    };
    var FirstView_1;
    // onLoad () {}
    FirstView.OPEN_A = "OPEN_A";
    FirstView.OPEN_B = "OPEN_B";
    FirstView = FirstView_1 = __decorate([
        ccclass
    ], FirstView);
    return FirstView;
}(BaseView_1.BaseView));
exports.default = FirstView;

cc._RF.pop();