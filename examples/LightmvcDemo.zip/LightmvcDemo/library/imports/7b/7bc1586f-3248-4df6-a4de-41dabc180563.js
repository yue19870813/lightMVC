"use strict";
cc._RF.push(module, '7bc15hvMkhN9qTeQdq8GAVj', 'ViewManager');
// libs/lightMVC/core/manager/ViewManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Constants_1 = require("../Constants");
var FrameworkCfg_1 = require("../FrameworkCfg");
/**
 * mvc框架控制类
 * @author ituuz
 * @description 负责控制和维护框架各个节点和结构间的跳转和关联。
 */
var ViewManager = /** @class */ (function () {
    /**
     * @constructor
     * @private
     */
    function ViewManager() {
        /** 上一场景类 */
        this._preSceneMediatorCls = null;
        this._preSceneViewCls = null;
        /** 当前场景类 */
        this._curSceneMediatorCls = null;
        this._curSceneViewCls = null;
        this._popViewList = [];
        this._layerViewList = [];
    }
    /**
     * 单例获取类
     */
    ViewManager.getInstance = function () {
        return this._instance;
    };
    /**
     * 运行场景
     * @param {{new(): BaseMediator}} mediator 场景mediator类型，类类型。
     * @param {{new(): BaseScene}} view 场景mediator类型，类类型。
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     * @param {()=>void} cb 加载完成回调.
     * @private
     */
    ViewManager.prototype.__runScene__ = function (mediator, view, data, cb) {
        var _this = this;
        // 创建并绑定场景
        var sceneMediator = new mediator();
        sceneMediator["__init__"]();
        sceneMediator.init(data);
        // 如果前一场景不为空则进行清理
        if (this._curScene) {
            this._curScene.destroy();
        }
        // 保存当前场景
        this._curScene = sceneMediator;
        if (this._curSceneMediatorCls != null && this._curSceneViewCls != null) {
            this._preSceneMediatorCls = this._curSceneMediatorCls;
            this._preSceneViewCls = this._curSceneViewCls;
        }
        this._curSceneMediatorCls = mediator;
        this._curSceneViewCls = view;
        // 处理场景显示逻辑
        var scenePath = (view).path();
        if (scenePath === "") {
            var ccs_1 = new cc.Scene();
            ccs_1.name = "Scene";
            var canvasNode = new cc.Node();
            canvasNode.name = "Canvas";
            var canvas = canvasNode.addComponent(cc.Canvas);
            canvas.designResolution = FrameworkCfg_1.default.DESIGN_RESOLUTION;
            canvas.fitHeight = FrameworkCfg_1.default.FIT_HEIGHT;
            canvas.fitWidth = FrameworkCfg_1.default.FIT_WIDTH;
            sceneMediator.view = canvasNode.addComponent(view);
            sceneMediator.view.__init__();
            ccs_1.addChild(canvasNode);
            // 这里延迟1ms是为了让场景在下一帧加载
            setTimeout(function () {
                _this.__closeAllView__();
                cc.director.runSceneImmediate(ccs_1);
                sceneMediator.viewDidAppear();
                cb && cb();
            }, 1);
        }
        else {
            cc.director.loadScene(scenePath, function () {
                _this.__closeAllView__();
                var canvas = cc.director.getScene().getChildByName('Canvas');
                if (canvas) {
                    sceneMediator.view = canvas.addComponent(view);
                    sceneMediator.view.__init__();
                    sceneMediator.viewDidAppear();
                    cb && cb();
                }
                else {
                    console.log("场景中必须包含默认的Canvas节点！");
                }
            });
        }
    };
    /**
     * 返回上一场景
     * @returns {boolean}是否存在上一个场景
     */
    ViewManager.prototype.__backScene__ = function () {
        if (this._preSceneMediatorCls && this._preSceneViewCls) {
            this.__runScene__(this._preSceneMediatorCls, this._preSceneViewCls);
            return true;
        }
        return false;
    };
    /**
     * 打开view界面
     * @param {{new(): BaseMediator}} mediator 界面mediator类型，类类型。
     * @param {{new(): BaseView}} view view 场景mediator类型，类类型。
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     * @param {OPEN_VIEW_OPTION} option 打开ui的操作选项，枚举类型。
     * @param {number} zOrder 层级。
     * @param {()=>void} cb 加载完成回调.
     */
    ViewManager.prototype.__showView__ = function (mediator, view, data, option, zOrder, cb) {
        var _this = this;
        // 处理打开UI的其他操作
        this.openViewOptionHandler(option);
        // 创建并绑定view
        var viewMediator = new mediator();
        viewMediator["__init__"]();
        // 处理场景显示逻辑
        var viewPath = (view).path();
        if (viewPath === "") {
            var viewNode = new cc.Node();
            this.initViewMediator(viewMediator, viewNode, view, option);
            viewMediator.init(data);
            viewMediator.viewDidAppear();
            cb && cb();
        }
        else {
            cc.loader.loadRes(viewPath, cc.Prefab, function (err, prefab) {
                if (err) {
                    console.error(err);
                    return;
                }
                var viewNode = cc.instantiate(prefab);
                _this.initViewMediator(viewMediator, viewNode, view, option);
                viewMediator.init(data);
                viewMediator.viewDidAppear();
                cb && cb();
            });
        }
    };
    /**
     * 初始化ViewMediator
     * @param {BaseMediator} mediator ViewMediator
     * @param {cc.Node} viewNode view显示节点
     * @param {{new(): BaseView}} view view显示组件类
     * @param {OPEN_VIEW_OPTION} option 打开选项
     * @param {number} zOrder 层级排序
     */
    ViewManager.prototype.initViewMediator = function (mediator, viewNode, view, option, zOrder) {
        viewNode.zIndex = zOrder;
        mediator.view = viewNode.addComponent(view);
        cc.director.getScene().getChildByName('Canvas').addChild(viewNode);
        mediator.view.__init__();
        // 根据不同打开类型，存储到不同队列中。
        if (option === Constants_1.OPEN_VIEW_OPTION.OVERLAY || option === Constants_1.OPEN_VIEW_OPTION.SINGLE) {
            this._popViewList.push(mediator);
        }
        else if (option === Constants_1.OPEN_VIEW_OPTION.LAYER) {
            this._layerViewList.push(mediator);
        }
    };
    /**
     * 关闭指定View
     * @param view
     * @private
     */
    ViewManager.prototype.__closeView__ = function (view) {
        for (var i = 0; i < this._popViewList.length; i++) {
            if (this._popViewList[i].view === view) {
                this._popViewList.splice(i, 1);
                return;
            }
        }
        for (var i = 0; i < this._layerViewList.length; i++) {
            if (this._layerViewList[i].view === view) {
                this._layerViewList.splice(i, 1);
                return;
            }
        }
    };
    /**
     * 关闭所有弹出窗口
     * @private
     */
    ViewManager.prototype.__closeAllPopView__ = function () {
        for (var i = 0; i < this._popViewList.length; i++) {
            this._popViewList[i].view["__onClose__"]();
        }
        this._popViewList = [];
    };
    /**
     * 关闭所有添加层级
     * @private
     */
    ViewManager.prototype.__closeAllAddLayer__ = function () {
        for (var i = 0; i < this._layerViewList.length; i++) {
            this._layerViewList[i].view["__onClose__"]();
        }
        this._layerViewList = [];
    };
    /**
     * 关闭所有view
     * @private
     */
    ViewManager.prototype.__closeAllView__ = function () {
        this.__closeAllPopView__();
        this.__closeAllAddLayer__();
    };
    /**
     * 根据参数处理ui的打开方式
     * @param option
     * @private
     */
    ViewManager.prototype.openViewOptionHandler = function (option) {
        // 设置默认值
        if (!option) {
            option = Constants_1.OPEN_VIEW_OPTION.OVERLAY;
        }
        // 根据不同操作做不同处理
        if (option === Constants_1.OPEN_VIEW_OPTION.SINGLE) {
            // TODO:暂时不提供这种关闭其他view的打开方式，可以通过BaseView.closeAllPopView()来实现。
        }
    };
    Object.defineProperty(ViewManager.prototype, "popViewList", {
        /**************************** getter and setter ******************************/
        get: function () {
            return this._popViewList;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewManager.prototype, "layerViewList", {
        get: function () {
            return this._layerViewList;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewManager.prototype, "curScene", {
        get: function () {
            return this._curScene;
        },
        enumerable: true,
        configurable: true
    });
    // 实例
    ViewManager._instance = new ViewManager();
    return ViewManager;
}());
exports.ViewManager = ViewManager;

cc._RF.pop();