"use strict";
cc._RF.push(module, '96c4d8XRfhO7KUYu/sl8lQb', 'BaseModel');
// libs/lightMVC/core/base/BaseModel.ts

Object.defineProperty(exports, "__esModule", { value: true });
var NotificationManager_1 = require("../manager/NotificationManager");
/**
 * 数据模型基类
 * init和clear接口需要子类重写
 */
var BaseModel = /** @class */ (function () {
    function BaseModel() {
    }
    /**
     * 发送消息接口
     * @param {string} noti 消息名称
     * @param {Object} data 消息数据
     */
    BaseModel.prototype.sendNoti = function (noti, data) {
        NotificationManager_1.default.getInstance().__sendNotification__(noti, data);
    };
    return BaseModel;
}());
exports.default = BaseModel;

cc._RF.pop();