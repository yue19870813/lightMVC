"use strict";
cc._RF.push(module, 'ad327DTnMRJp44xOk9Qj8CV', 'DefaultSceneMediator');
// script/view/DefaultSceneMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseMediator_1 = require("../../libs/lightMVC/core/base/BaseMediator");
var FirstMediator_1 = require("./first/FirstMediator");
var FirstView_1 = require("./first/FirstView");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var DefaultSceneMediator = /** @class */ (function (_super) {
    __extends(DefaultSceneMediator, _super);
    function DefaultSceneMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DefaultSceneMediator.prototype.init = function (data) {
        console.log("打开场景时传递的参数:", data);
        this._data = data;
    };
    DefaultSceneMediator.prototype.viewDidAppear = function () {
        console.log("viewDidAppear ===>>>", this._data);
        // 打开第一个UI
        this.addLayer(FirstMediator_1.default, FirstView_1.default, 1, this._data);
    };
    DefaultSceneMediator.prototype.destroy = function () {
    };
    DefaultSceneMediator = __decorate([
        ccclass
    ], DefaultSceneMediator);
    return DefaultSceneMediator;
}(BaseMediator_1.default));
exports.default = DefaultSceneMediator;

cc._RF.pop();