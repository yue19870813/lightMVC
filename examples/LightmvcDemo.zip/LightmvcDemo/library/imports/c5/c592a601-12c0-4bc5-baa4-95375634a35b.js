"use strict";
cc._RF.push(module, 'c592aYBEsBLxbqklTdWNKNb', 'CommandManager');
// libs/lightMVC/core/manager/CommandManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SimpleCommand_1 = require("../command/SimpleCommand");
var SyncMacroCommand_1 = require("../command/SyncMacroCommand");
var AsyncMacroCommand_1 = require("../command/AsyncMacroCommand");
var CommandManager = /** @class */ (function () {
    /**
     * @constructor
     * @private
     */
    function CommandManager() {
    }
    /**
     * 单例获取类
     */
    CommandManager.getInstance = function () {
        return this._instance;
    };
    /**
     * 执行命令
     * @param {{new (): BaseCommand}} command 命令对象
     * @param {Object} body 命令参数
     */
    CommandManager.prototype.__executeCommand__ = function (command, body) {
        if (cc.js.isChildClassOf(command, SimpleCommand_1.default)) {
            var cmd = new command();
            cmd.execute(body);
        }
        else if (cc.js.isChildClassOf(command, SyncMacroCommand_1.default)) {
            // TODO: 同步按顺序执行的命令组合宏
        }
        else if (cc.js.isChildClassOf(command, AsyncMacroCommand_1.default)) {
            var cmd = new command();
            // 初始化宏
            cmd["initialize"]();
            // 执行
            cmd["asyncExecute"]();
        }
        else {
            console.log(command.prototype + " 不是可执行的命令！");
        }
    };
    /**
     * 撤销命令
     * @param {{new (): BaseCommand}} command 命令对象
     * @param {Object} body 命令参数
     */
    CommandManager.prototype.__undoCommand__ = function (command, body) {
        if (cc.js.isChildClassOf(command, SimpleCommand_1.default)) {
            var cmd = new command();
            cmd.undo(body);
        }
        else if (cc.js.isChildClassOf(command, SyncMacroCommand_1.default)) {
            // TODO: 同步按顺序撤销的命令组合宏
        }
        else if (cc.js.isChildClassOf(command, AsyncMacroCommand_1.default)) {
            var cmd = new command();
            // 初始化宏
            cmd["initialize"]();
            // 执行
            cmd["asyncUndo"]();
        }
        else {
            console.log(command.prototype + " 不是可执行的命令！");
        }
    };
    // 实例
    CommandManager._instance = new CommandManager();
    return CommandManager;
}());
exports.default = CommandManager;

cc._RF.pop();