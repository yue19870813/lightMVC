"use strict";
cc._RF.push(module, 'd964e0M45dCFYwYmYRLS/Sp', 'BaseCommand');
// libs/lightMVC/core/base/BaseCommand.ts

/**
 * 命令基类
 */
Object.defineProperty(exports, "__esModule", { value: true });
var BaseCommand = /** @class */ (function () {
    function BaseCommand() {
    }
    return BaseCommand;
}());
exports.default = BaseCommand;

cc._RF.pop();