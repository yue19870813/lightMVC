"use strict";
cc._RF.push(module, 'df25c21iR1M1pcN4aKwU0Js', 'Notification');
// script/Notification.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Notification = /** @class */ (function () {
    function Notification() {
    }
    Notification.UPDATE_EXP_FINISH = "UPDATE_EXP_FINISH";
    return Notification;
}());
exports.default = Notification;

cc._RF.pop();