"use strict";
cc._RF.push(module, 'f166epQXRVCUoe5b/Q3ET6a', 'AsyncMacroCommand');
// libs/lightMVC/core/command/AsyncMacroCommand.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 异步组合宏命令基类
 * 该组合宏中的子命令是同步执行的，会按照添加的顺序同步执行。
 */
var MacroCommand_1 = require("./MacroCommand");
var AsyncMacroCommand = /** @class */ (function (_super) {
    __extends(AsyncMacroCommand, _super);
    function AsyncMacroCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * 异步执行组合命令
     */
    AsyncMacroCommand.prototype.asyncExecute = function () {
        var cmdList = this["_commandList"];
        for (var _i = 0, cmdList_1 = cmdList; _i < cmdList_1.length; _i++) {
            var cmd = cmdList_1[_i];
            var tempCmd = new cmd.cmd();
            tempCmd.execute(cmd.body);
        }
    };
    /**
     * 异步撤销组合命令
     */
    AsyncMacroCommand.prototype.asyncUndo = function () {
        var cmdList = this["_commandList"];
        for (var _i = 0, cmdList_2 = cmdList; _i < cmdList_2.length; _i++) {
            var cmd = cmdList_2[_i];
            var tempCmd = new cmd.cmd();
            tempCmd.undo(cmd.body);
        }
    };
    return AsyncMacroCommand;
}(MacroCommand_1.default));
exports.default = AsyncMacroCommand;

cc._RF.pop();