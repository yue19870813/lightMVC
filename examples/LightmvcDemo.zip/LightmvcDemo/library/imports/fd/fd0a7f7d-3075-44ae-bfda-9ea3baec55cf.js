"use strict";
cc._RF.push(module, 'fd0a799MHVErr/anqO67FXP', 'FirstMediator');
// script/view/first/FirstMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseMediator_1 = require("../../../libs/lightMVC/core/base/BaseMediator");
var FirstView_1 = require("./FirstView");
var PopAMediator_1 = require("../pop_a/PopAMediator");
var PopAView_1 = require("../pop_a/PopAView");
var PopBMediator_1 = require("../pop_b/PopBMediator");
var PopBView_1 = require("../pop_b/PopBView");
var FirstMediator = /** @class */ (function (_super) {
    __extends(FirstMediator, _super);
    function FirstMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FirstMediator.prototype.init = function (data) {
        var _this = this;
        console.log("FirstMediator::init===>>>", data);
        this.view.setData(data);
        this.bindEvent(FirstView_1.default.OPEN_A, function (str) {
            _this.popView(PopAMediator_1.default, PopAView_1.default, str);
        }, this);
        this.bindEvent(FirstView_1.default.OPEN_B, function (str) {
            _this.popView(PopBMediator_1.default, PopBView_1.default, str);
        }, this);
    };
    FirstMediator.prototype.viewDidAppear = function () {
    };
    FirstMediator.prototype.destroy = function () {
    };
    return FirstMediator;
}(BaseMediator_1.default));
exports.default = FirstMediator;

cc._RF.pop();