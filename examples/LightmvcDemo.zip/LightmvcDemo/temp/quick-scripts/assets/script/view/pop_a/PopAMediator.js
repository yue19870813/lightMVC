(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/pop_a/PopAMediator.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '66072JptXBHdLGAKmgLx+B9', 'PopAMediator', __filename);
// script/view/pop_a/PopAMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseMediator_1 = require("../../../libs/lightMVC/core/base/BaseMediator");
var PopAView_1 = require("./PopAView");
var PlayerModel_1 = require("../../model/PlayerModel");
var PlayerCommand_1 = require("../../command/PlayerCommand");
var Notification_1 = require("../../Notification");
var PopAMediator = /** @class */ (function (_super) {
    __extends(PopAMediator, _super);
    function PopAMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PopAMediator.prototype.init = function (data) {
        var _this = this;
        this.view.drawView(data);
        var playerModel = this.getModel(PlayerModel_1.default);
        this.view.setLevelDisplay(playerModel.getPlayerLv());
        // 监听修改经验事件
        this.bindEvent(PopAView_1.default.UPDATE_LEVEL, function (exp) {
            _this.sendCmd(PlayerCommand_1.UpdateExpCommand, exp);
        }, this);
        this.registerNoti(Notification_1.default.UPDATE_EXP_FINISH, function () {
            _this.view.setLevelDisplay(playerModel.getPlayerLv());
        }, this);
    };
    PopAMediator.prototype.viewDidAppear = function () {
    };
    PopAMediator.prototype.destroy = function () {
    };
    return PopAMediator;
}(BaseMediator_1.default));
exports.default = PopAMediator;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PopAMediator.js.map
        