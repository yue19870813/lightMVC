(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/pop_b/PopBMediator.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'c86f9AAJFdAQIHDdoBOKuYq', 'PopBMediator', __filename);
// script/view/pop_b/PopBMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseMediator_1 = require("../../../libs/lightMVC/core/base/BaseMediator");
var PopBView_1 = require("./PopBView");
var SecondSceneMediator_1 = require("../SecondSceneMediator");
var SecondScene_1 = require("../SecondScene");
var PopBMediator = /** @class */ (function (_super) {
    __extends(PopBMediator, _super);
    function PopBMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PopBMediator.prototype.init = function (data) {
        var _this = this;
        this.view.drawView(data);
        this.bindEvent(PopBView_1.default.RUN_SECOND_SCENE, function () {
            _this.runScene(SecondSceneMediator_1.default, SecondScene_1.default);
        }, this);
    };
    PopBMediator.prototype.viewDidAppear = function () {
    };
    PopBMediator.prototype.destroy = function () {
    };
    return PopBMediator;
}(BaseMediator_1.default));
exports.default = PopBMediator;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PopBMediator.js.map
        